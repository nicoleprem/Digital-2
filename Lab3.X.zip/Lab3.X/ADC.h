  
//*****************************************************************************
//Prototipos de funciones
//*****************************************************************************
#ifndef ADC
#define	ADC

#include <xc.h> // include processor files - each processor file is guarded.  

uint8_t AADC(uint8_t banderaADC, uint8_t Num_Pot);

#endif	/* XC_HEADER_TEMPLATE_H */
