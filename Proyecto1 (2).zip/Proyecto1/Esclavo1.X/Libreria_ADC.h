 
#ifndef Libreria_ADC
#define	Libreria_ADC

#include <xc.h> // include processor files - each processor file is guarded. 
#include <stdint.h>

void AADC(uint8_t banderaADC);



#endif	/* XC_HEADER_TEMPLATE_H */

