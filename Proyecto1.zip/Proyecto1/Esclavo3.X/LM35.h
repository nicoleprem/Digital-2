
#ifndef LM35
#define	LM35

#include <xc.h> 
#include <stdint.h>

void LM (uint8_t banderaLM);

#endif	/* XC_HEADER_TEMPLATE_H */

